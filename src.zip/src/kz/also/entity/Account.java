package kz.also.entity;

public class Account {
	private int id;
	private String name;
	private String phoneNumber;
	private int balance;
	private int bankid;
	public Account(int id, String name, String phoneNumber, int balance, int bankid) {
		super();
		this.id = id;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.balance = balance;
		this.bankid = bankid;
	}
	public int getBankid() {
		return bankid;
	}
	public void setBankid(int bankid) {
		this.bankid = bankid;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [id=" + id + ", name=" + name + ", phoneNumber=" + phoneNumber + ", balance=" + balance + "]";
	}
	
}
