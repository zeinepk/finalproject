package kz.also.applications;

import java.util.Random;
import java.util.Scanner;

import kz.also.controller.BankController;
import kz.also.entity.Account;
import kz.also.interfaces.GUIApp;

public class CustomerApplication implements GUIApp {
	private BankController controller;
	public CustomerApplication(BankController controller) {
		this.controller = controller;
	}
	@Override
	public void openAccount(Scanner scanner) {
		System.out.println("Hello, it is a create account menu \n Can you tell me your name?");
		String name = scanner.next();
		System.out.println("Ok, you just need to send me a account number of phone");
		String phoneNumber = scanner.next();
		System.out.println("You just need to send me your balance, which you need to drop");
		int balance = scanner.nextInt();
		System.out.println("And last: bank id, which you need to drop");
		int bankid = scanner.nextInt();
		Account account = new Account(new Random().nextInt(999999), name, phoneNumber, balance, bankid);
		this.controller.addAccount(account);
		System.out.println("Successfully add your account!");
		System.out.println("Information: " + account.toString());
		
	}
	@Override
	public void searchByAccount(Scanner scanner) {
		System.out.println("Send me id of which information you find");
		int id = scanner.nextInt();
		Account account = this.controller.getAccount(id);
		if(account != null){
			System.out.println("Account successfully found!");
			System.out.println("Information: " + account.toString());
		}  
		
	}
	@Override
	public void deposite(Scanner scanner) {
		System.out.println("Send me a id of your account, and sum of deposite");
		int id = scanner.nextInt();
		Account account = this.controller.getAccount(id);
		System.out.println("Sum of deposite: ");
		int dollars = scanner.nextInt();
		if(account != null && dollars > 0) {
			this.controller.depositeMoney(id, dollars);
			account.setBalance(account.getBalance() + dollars);
			System.out.println("Dollars has been sended");
		} else {
			System.out.println("Wrong account id or your sum less then 0");
		}
		System.out.println(account.toString());
		
	}
	@Override
	public void withdrawal(Scanner scanner) {
		System.out.println("Send me a id of your account, and sum of withdrawal");
		int id = scanner.nextInt();
		Account account = this.controller.getAccount(id);
		System.out.println("Sum of withdrawal: ");
		int dollars = scanner.nextInt();
		if(account != null && (account.getBalance() - dollars) > 0) {
			this.controller.withdrawal(id, dollars);
			account.setBalance(account.getBalance() - dollars);
			System.out.println("Dollars has been withdrawaled");
		} else {
			System.out.println("Wrong account id or your balance less then you want to withdrawal");
		}
		System.out.println(account.toString());
		
	}
}
