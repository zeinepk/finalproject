package kz.also.applications;

import java.util.Scanner;

import kz.also.controller.BankController;
import kz.also.interfaces.GUIApp;

public class Application {
	public static boolean isEnable = true;
	public void start(BankController controller) {
		System.out.println("Hi, it is a bank program, if you needed to connect a common user, send me a 1 \n Or if you a bank workers, send me 2");
		Scanner scanner = new Scanner(System.in);
		int number;
		while(true) {
			number = scanner.nextInt();
			switch(number) {
			case 1:
				if(isEnable) {
					this.startCustomers(scanner, controller);
				} else {
					System.out.println("Sorry, bank have a technical problem");
				}
				break;
			case 2:
				this.startBank(scanner);
				break;
			default:
				System.out.println("Exit from program");
				return;
			}
		}
	}
	
	
	public void startCustomers(Scanner scanner, BankController controller) {
		GUIApp app = new CustomerApplication(controller);
		int choose;
		while(true) {
			System.out.println("Main Menu \n 1. Open your account\n 2. Search By Account\n 3. Deposit\n 4. Withdrawal\n 5.Exit ");
			choose = scanner.nextInt();
			switch(choose) {
			case 1:
				app.openAccount(scanner);
				break;
			case 2:
				app.searchByAccount(scanner);
				break;
			case 3:
				app.deposite(scanner);
				break;
			case 4:
				app.withdrawal(scanner);
				break;
			default:
				System.out.println("Back to the main menu");
				return;
			}
		}
	}
	
	public void startBank(Scanner scanner) {
		String str = scanner.next();
		BankApplication app = new BankApplication();
		if(str.equals("pass12345")) {
			System.out.println("Send me a 1 if you needed to stop a bank functionality");
			int number = scanner.nextInt();
			switch(number) {
			case 1:
				app.disableOfBank();
				System.out.println("Bank has been disabled!");
				break;
			default:
				return;
			}
		} else {
			System.out.println("not correct password, sorry");
		}
		System.out.println("Exit to the main menu");
	}
}
