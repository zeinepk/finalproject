package kz.also.applications;

public class BankApplication {
	public void disableOfBank() {
		Application.isEnable = !Application.isEnable;
	}
}
