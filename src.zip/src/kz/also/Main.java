package kz.also;

import com.company.data.PostgresDB;
import com.company.interfaces.IDB;

import kz.also.applications.Application;
import kz.also.controller.BankController;

public class Main {
	
	public static void main(String[] args) {
		IDB idb = new PostgresDB();
		Application app = new Application();
		BankController controller = new BankController(idb);
		app.start(controller);
	}

}
