package kz.also.interfaces;

import java.util.Scanner;

public interface GUIApp {
	public void openAccount(Scanner scanner);
	public void searchByAccount(Scanner scanner);
	public void deposite(Scanner scanner);
	public void withdrawal(Scanner scanner);
}
