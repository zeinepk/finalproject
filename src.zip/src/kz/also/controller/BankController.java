package kz.also.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.company.interfaces.IDB;

import kz.also.entity.Account;

public class BankController {
	private IDB db;
	public BankController(IDB db) {
		this.db = db;
	}
	public void withdrawal(int id, int dollars) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "UPDATE accounts SET account_balance = account_balance - ? WHERE account_id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, dollars);
            st.setInt(2, id);
       
            st.execute();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
	public void depositeMoney(int id, int dollars) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "UPDATE accounts SET account_balance = account_balance + ? WHERE account_id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, dollars);
            st.setInt(2, id);
            
            st.execute();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
	public Account getAccount(int id) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "SELECT * FROM accounts WHERE account_id=?";
            PreparedStatement st = con.prepareStatement(sql);

            st.setInt(1, id);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {
               Account account = new Account(rs.getInt("account_id"), 
            		   rs.getString("account_name"), 
            		   rs.getString("account_phoneNumber"), 
            		   rs.getInt("account_balance"), rs.getInt("bank_id"));
                return account;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return null;
    }
	public boolean addAccount(Account account) {
        Connection con = null;
        try {
            con = db.getConnection();
            String sql = "INSERT INTO accounts(account_id, account_name, account_phoneNumber, account_balance, bank_id) VALUES (?,?,?,?,?)";
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, account.getId());
            st.setString(2, account.getName());
            st.setString(3, account.getPhoneNumber());
            st.setInt(4, account.getBalance());
            st.setInt(5, account.getBankid());
            st.execute();
            return true;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return false;
    }
	
}
